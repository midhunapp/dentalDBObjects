use [DHCM]
insert into InventoryGroup_Mf(Name,IsInvenoryGroup) values('Lab','N')
insert into InventoryGroup_Mf(Name,IsInvenoryGroup) values('Material','Y')
insert into InventoryGroup_Mf(Name,IsInvenoryGroup) values('Instruments','Y')
insert into InventoryGroup_Mf(Name,IsInvenoryGroup) values('Consumerables','Y')

